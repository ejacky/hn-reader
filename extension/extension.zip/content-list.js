(function() {
  'use strict';

  console.log('[HN Reader] content-list.js loaded');

  // 按钮文案会在不同状态之间做相等比较，先算好，避免每次重新取。
  // 列表页用 [summary]，评论页（content-item.js）用 [summarize]，两者不要合并。
  // 界面语言要等 i18n 就绪后才能确定，所以在 init() 里生成。
  let LABEL = null;

  function buildLabels() {
    LABEL = {
      summary: ` ${t('btnSummary')}`,
      loading: ` ${t('btnLoading')}`,
      failed: ` ${t('btnFailed')}`,
      quotaExceeded: ` ${t('btnQuotaExceeded')}`,
      rateLimited: ` ${t('btnRateLimited')}`,
      serviceBusy: ` ${t('btnServiceBusy')}`
    };
  }

  async function sendToBg(action, payload) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ action, payload }, (response) => {
        if (chrome.runtime.lastError) {
          const err = new Error(chrome.runtime.lastError.message);
          err.status = 0;
          reject(err);
          return;
        }
        if (!response || !response.ok) {
          const err = new Error(response?.error || 'Unknown error');
          err.status = response?.status || 0;
          err.code = response?.code || '';
          reject(err);
          return;
        }
        resolve(response.data);
      });
    });
  }

  async function sendSignal(targetType, targetId, signalType, strength, context) {
    try {
      await sendToBg('sendSignal', {
        target_type: targetType,
        target_id: targetId,
        signal_type: signalType,
        strength: strength,
        context: context || {}
      });
    } catch (e) {
      console.error('[HN Reader] send signal failed:', e);
    }
  }

  async function fetchSummary(hnId, url, title) {
    const result = await chrome.storage.local.get(['hn_reader_language']);
    const lang = result['hn_reader_language'] || defaultSummaryLanguage();
    return await sendToBg('summarizeArticle', { hn_id: hnId, url: url, title: title, lang: lang });
  }

  const PRELOAD_BATCH = 15;
  const PRELOAD_POLL_MS = 3000;
  // 单条等待上限。服务端 3 个 worker 抢 15 条，每条最多 6 次 LLM 请求、单次
  // 最长 90 秒，尾部条目光是排队就可能数分钟，所以按条目计时并给足余量。
  const PRELOAD_TIMEOUT_MS = 300000;
  // 超时后仍可能补到结果，持续慢速复查到页面卸载，避免把"还在跑"判成"永久失败"
  const PRELOAD_LATE_POLL_MS = 30000;
  const PRELOAD_FAILED_STATUSES = new Set([
    'invalid', 'quota_exceeded', 'user_limit', 'queue_full', 'closed', 'request_failed'
  ]);
  const preloadPending = new Set();
  const preloadStartedAt = new Map();
  const preloadTimers = new Set();
  let preloadPollInFlight = false;
  let preloadStarted = false;

  function clearPreloadTimers() {
    preloadTimers.forEach(id => clearInterval(id));
    preloadTimers.clear();
  }

  function trackPending(hnId) {
    const id = Number(hnId);
    preloadPending.add(id);
    if (!preloadStartedAt.has(id)) preloadStartedAt.set(id, Date.now());
  }

  function untrackPending(hnId) {
    const id = Number(hnId);
    preloadPending.delete(id);
    preloadStartedAt.delete(id);
  }

  async function preloadArticles(articles) {
    if (articles.length === 0) return { results: null };
    try {
      const data = await sendToBg('preloadArticles', { articles });
      return { results: data && Array.isArray(data.results) ? data.results : null };
    } catch (e) {
      console.error('[HN Reader] preload request failed:', e);
      return { results: null, error: e };
    }
  }

  function markPreloaded(hnId) {
    const btn = document.querySelector(`a[data-hn-reader-summary][data-hn-id="${hnId}"]`);
    if (!btn) return;
    btn.dataset.hnReaderPreloaded = 'true';
    delete btn.dataset.hnReaderPreloadFailed;
    delete btn.dataset.hnReaderPreloadFailedReason;
    // 如果当前摘要弹窗正打开，不要覆盖蓝色激活状态
    const popupOpen = document.querySelector(`.hn-reader-popup[data-hn-reader-hn-id="${hnId}"]`);
    if (!popupOpen) {
      btn.style.color = '#228b22';
      btn.title = t('preloaded');
    }
  }

  function preloadFailedTitle(reason) {
    return reason === 'quota_exceeded' ? t('preloadQuotaExceeded') : t('preloadFailed');
  }

  function markPreloadFailed(hnId, reason) {
    const btn = document.querySelector(`a[data-hn-reader-summary][data-hn-id="${hnId}"]`);
    if (!btn || btn.dataset.hnReaderPreloaded === 'true') return;
    // 记住失败态和原因，避免弹窗开合后 setSummaryBtnState 把文案降级成默认橙色
    btn.dataset.hnReaderPreloadFailed = 'true';
    btn.dataset.hnReaderPreloadFailedReason = reason || '';
    btn.style.color = '#999';
    btn.title = preloadFailedTitle(reason);
  }

  function applyPreloadResults(results) {
    results.forEach(r => {
      const id = Number(r.hn_id);
      switch (r.status) {
        case 'queued':
        case 'duplicate':
          // duplicate 表示同一篇已有一份在跑，等它完成即可
          trackPending(id);
          break;
        case 'cached':
          untrackPending(id);
          markPreloaded(id);
          break;
        default:
          untrackPending(id);
          if (PRELOAD_FAILED_STATUSES.has(r.status)) {
            markPreloadFailed(id, r.status);
          } else {
            // 未知状态（服务端新增取值）按待定处理，不要误判成失败
            trackPending(id);
          }
      }
    });
  }

  async function pollPreloadStatus(articleIds, lang) {
    if (articleIds.length === 0) return [];
    try {
      const data = await sendToBg('preloadStatus', { ids: articleIds.join(','), lang });
      const ready = (data && data.ready_ids) || [];
      ready.forEach(id => {
        untrackPending(id);
        markPreloaded(id);
      });
      return ready;
    } catch (e) {
      console.error('[HN Reader] preload status poll failed:', e);
      return [];
    }
  }

  function scheduleLatePoll(ids, lang) {
    if (ids.length === 0) return;
    const remaining = ids.slice();
    const timer = setInterval(async () => {
      if (remaining.length === 0) {
        clearInterval(timer);
        preloadTimers.delete(timer);
        return;
      }
      const ready = await pollPreloadStatus(remaining, lang);
      const readySet = new Set(ready.map(Number));
      for (let i = remaining.length - 1; i >= 0; i--) {
        if (readySet.has(remaining[i])) remaining.splice(i, 1);
      }
    }, PRELOAD_LATE_POLL_MS);
    preloadTimers.add(timer);
  }

  function expirePendingPreloads(lang) {
    const now = Date.now();
    const expired = [];
    preloadPending.forEach(id => {
      const started = preloadStartedAt.get(id) || now;
      if (now - started > PRELOAD_TIMEOUT_MS) expired.push(id);
    });
    if (expired.length === 0) return;
    expired.forEach(id => {
      untrackPending(id);
      markPreloadFailed(id, 'timeout');
    });
    // 慢速复查：服务端可能只是排在长队后面，晚到的结果仍要把灰色改成绿色
    scheduleLatePoll(expired, lang);
  }

  function showNoticeTip(targetBtn, title, message) {
    // 移除已存在的提示
    const existing = document.getElementById('hn-reader-quota-tip');
    if (existing) existing.remove();

    const tip = document.createElement('div');
    tip.id = 'hn-reader-quota-tip';
    tip.className = 'hn-reader-popup';
    tip.style.cssText = `
      position: fixed;
      z-index: 99999;
      background: #fff;
      border: 1px solid #ff6600;
      border-radius: 6px;
      padding: 12px;
      width: 260px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      font-family: Verdana, Geneva, sans-serif;
      font-size: 12px;
      line-height: 1.5;
      color: #000;
    `;
    tip.innerHTML = `
      <div style="font-weight:bold;color:#ff6600;margin-bottom:6px;">${title}</div>
      <div style="margin-bottom:10px;color:#666;">${message}</div>
      <button id="hn-reader-quota-close" style="background:#ff6600;color:#fff;border:none;padding:5px 12px;border-radius:3px;cursor:pointer;font-size:11px;">${t('gotIt')}</button>
    `;

    const rect = targetBtn.getBoundingClientRect();
    tip.style.top = (rect.bottom + 6) + 'px';
    tip.style.left = rect.left + 'px';
    document.body.appendChild(tip);

    document.getElementById('hn-reader-quota-close').addEventListener('click', () => tip.remove());

    setTimeout(() => {
      if (tip.parentNode) tip.remove();
    }, 8000);
  }

  function showQuotaExceededTip(targetBtn) {
    showNoticeTip(
      targetBtn,
      t('quotaTipTitle'),
      t('quotaTipBody')
    );
  }

  function setSummaryBtnState(hnId, active) {
    const btn = document.querySelector(`a[data-hn-reader-summary][data-hn-id="${hnId}"]`);
    if (!btn) return;
    if (active) {
      delete btn.dataset.hnReaderPreloadFailed;
      btn.style.color = '#0066cc';
      btn.title = t('summaryOpened');
    } else if (btn.dataset.hnReaderPreloaded === 'true') {
      btn.style.color = '#228b22';
      btn.title = t('preloaded');
    } else if (btn.dataset.hnReaderPreloadFailed === 'true') {
      btn.style.color = '#999';
      btn.title = preloadFailedTitle(btn.dataset.hnReaderPreloadFailedReason || '');
    } else {
      btn.style.color = '#ff6600';
      btn.title = '';
    }
  }

  function createSummaryCard(data, hnId, title) {
    const card = document.createElement('div');
    card.className = 'hn-reader-summary-card hn-reader-popup';
    if (!window.__hnReaderPopupCounter) window.__hnReaderPopupCounter = 0;
    card.dataset.hnReaderPopupId = ++window.__hnReaderPopupCounter;
    card.dataset.hnReaderHnId = hnId;
    card.style.cssText = `
      position: fixed;
      z-index: 99999;
      background: #f6f6ef;
      border: 1px solid #ff6600;
      border-radius: 4px;
      padding: 12px;
      width: 420px;
      max-width: 90vw;
      max-height: 80vh;
      overflow-y: auto;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      font-family: Verdana, Geneva, sans-serif;
      font-size: 12px;
      line-height: 1.5;
      color: #000;
    `;

    const header = document.createElement('div');
    header.style.cssText = `
      display: none;
      margin: -6px 0 4px 0;
      padding-top: 2px;
      font-size: 11px;
      color: #888;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    `;
    header.textContent = title || t('untitled');
    card.appendChild(header);

    const summaryP = document.createElement('p');
    summaryP.style.margin = '0 0 8px 0';
    summaryP.style.fontWeight = 'bold';
    summaryP.textContent = data.summary || t('noSummary');
    card.appendChild(summaryP);

    if (data.key_points && data.key_points.length > 0) {
      const ul = document.createElement('ul');
      ul.style.margin = '0';
      ul.style.paddingLeft = '16px';
      data.key_points.forEach(kp => {
        const li = document.createElement('li');
        li.style.marginBottom = '2px';
        li.textContent = kp;
        ul.appendChild(li);
      });
      card.appendChild(ul);
    }

    const closeBtn = document.createElement('button');
    closeBtn.textContent = t('closeCard');
    closeBtn.style.cssText = `
      margin-top: 8px;
      background: #ff6600;
      color: #fff;
      border: none;
      padding: 4px 10px;
      cursor: pointer;
      font-size: 11px;
      border-radius: 2px;
    `;
    closeBtn.onclick = () => {
      setSummaryBtnState(hnId, false);
      card.remove();
    };
    closeBtn.addEventListener('mousedown', (e) => e.stopPropagation());
    card.appendChild(closeBtn);

    makeDraggable(card, () => {
      header.style.display = 'block';
    });
    return card;
  }

  function makeDraggable(el, onDragStart) {
    let isDragging = false;
    let startX, startY, initLeft, initTop;

    el.addEventListener('mousedown', (e) => {
      isDragging = false;
      startX = e.clientX;
      startY = e.clientY;
      initLeft = parseFloat(el.style.left) || 0;
      initTop = parseFloat(el.style.top) || 0;

      const onMove = (ev) => {
        const dx = ev.clientX - startX;
        const dy = ev.clientY - startY;
        if (!isDragging && (Math.abs(dx) > 3 || Math.abs(dy) > 3)) {
          isDragging = true;
          if (onDragStart) onDragStart();
          el.style.cursor = 'grabbing';
          el.style.userSelect = 'none';
        }
        if (isDragging) {
          el.style.left = (initLeft + dx) + 'px';
          el.style.top = (initTop + dy) + 'px';
        }
      };

      const onUp = () => {
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
        el.style.cursor = '';
        el.style.userSelect = '';
      };

      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
    });
  }

  function injectSummaryButtons() {
    if (!LABEL) return;
    const rows = document.querySelectorAll('.athing');
    console.log('[HN Reader] found', rows.length, '.athing rows');

    rows.forEach(row => {
      if (row.dataset.hnReaderInjected) return;
      row.dataset.hnReaderInjected = 'true';

      const titleline = row.querySelector('span.titleline');
      if (!titleline) {
        console.log('[HN Reader] no titleline in row', row.id);
        return;
      }

      const titleLink = titleline.querySelector('a');
      if (!titleLink) {
        console.log('[HN Reader] no link in titleline');
        return;
      }

      const hnId = parseInt(row.id, 10);
      if (!hnId) {
        console.log('[HN Reader] no hnId');
        return;
      }

      const url = titleLink.href;
      const title = titleLink.textContent;

      const btn = document.createElement('a');
      btn.href = 'javascript:void(0)';
      btn.textContent = LABEL.summary;
      btn.style.color = '#ff6600';
      btn.style.fontSize = '10px';
      btn.style.textDecoration = 'none';
      btn.style.cursor = 'pointer';
      btn.style.marginLeft = '4px';
      btn.setAttribute('data-hn-reader-summary', 'true');
      btn.setAttribute('data-hn-id', hnId);

      const titleCell = titleline.closest('td.title');

      let card = null;
      btn.addEventListener('click', async (e) => {
        e.preventDefault();
        e.stopPropagation();

        if (card) {
          setSummaryBtnState(hnId, false);
          card.remove();
          card = null;
          return;
        }

        if (btn.dataset.hnReaderQuotaExceeded === 'true') {
          showQuotaExceededTip(btn);
          return;
        }

        btn.textContent = LABEL.loading;
        try {
          const data = await fetchSummary(hnId, url, title);
          card = createSummaryCard(data, hnId, title);
          const rect = btn.getBoundingClientRect();
          card.style.top = (rect.bottom + 4) + 'px';
          card.style.left = rect.left + 'px';
          document.body.appendChild(card);
          btn.dataset.hnReaderPreloaded = 'true';
          setSummaryBtnState(hnId, true);
          await sendSignal('article', hnId, 'summary_viewed', 1, { title });
        } catch (err) {
          console.error('[HN Reader] summarize error:', err);
          if (err.code === 'quota_exceeded' || (err.status === 429 && !err.code)) {
            btn.textContent = LABEL.quotaExceeded;
            btn.style.color = '#e00';
            btn.title = t('quotaExceededBtnTitle');
            btn.dataset.hnReaderQuotaExceeded = 'true';
          } else if (err.code === 'rate_limited') {
            btn.textContent = LABEL.rateLimited;
            btn.style.color = '#e00';
            btn.title = t('rateLimitedTooltip');
            showNoticeTip(btn, t('rateLimitedNoticeTitle'), t('rateLimitedNoticeBody'));
            setTimeout(() => {
              if (btn.textContent === LABEL.rateLimited) {
                btn.textContent = LABEL.summary;
                btn.style.color = '#ff6600';
                btn.title = '';
              }
            }, 5000);
          } else if (err.code === 'service_busy' || err.code === 'llm_unavailable') {
            btn.textContent = LABEL.serviceBusy;
            btn.style.color = '#e00';
            btn.title = t('serviceBusyTooltip');
            setTimeout(() => {
              if (btn.textContent === LABEL.serviceBusy) {
                btn.textContent = LABEL.summary;
                btn.style.color = '#ff6600';
                btn.title = '';
              }
            }, 5000);
          } else {
            btn.textContent = LABEL.failed;
            btn.style.color = '#e00';
            btn.title = t('summaryFailed', [err.message]);
            setTimeout(() => {
              btn.textContent = LABEL.summary;
              btn.style.color = '#ff6600';
              btn.title = '';
            }, 3000);
          }
        } finally {
          if (btn.textContent === LABEL.loading) {
            btn.textContent = LABEL.summary;
          }
        }
      });

      titleline.appendChild(btn);

      titleLink.addEventListener('click', () => {
        sendSignal('article', hnId, 'article_clicked', 3, { title, url });
      });
    });
  }

  async function applyInterestMatches() {
    const rows = document.querySelectorAll('.athing');
    const articles = [];
    const rowMap = new Map();

    rows.forEach(row => {
      const titleline = row.querySelector('span.titleline');
      if (!titleline) return;
      const titleLink = titleline.querySelector('a');
      if (!titleLink) return;
      const hnId = parseInt(row.id, 10);
      if (!hnId) return;
      const title = titleLink.textContent;
      let domain = '';
      const siteBit = titleline.querySelector('span.sitestr');
      if (siteBit) {
        domain = siteBit.textContent.trim();
      }
      articles.push({ hn_id: hnId, title, domain });
      rowMap.set(hnId, row);
    });

    if (articles.length === 0) return;

    try {
      const data = await sendToBg('batchMatch', { articles });
      if (!data.matches) return;

      data.matches.forEach(match => {
        const row = rowMap.get(match.hn_id);
        if (!row) return;

        const titleline = row.querySelector('span.titleline');
        if (!titleline) return;

        if (match.match_type === 'high') {
          row.style.borderLeft = '3px solid #ff6600';
          row.style.paddingLeft = '4px';
        } else if (match.match_type === 'medium') {
          row.style.borderLeft = '2px solid #ffb380';
          row.style.paddingLeft = '4px';
        }

        if (match.match_tags && match.match_tags.length > 0) {
          const tagSpan = document.createElement('span');
          tagSpan.style.cssText = 'font-size: 10px; color: #666; margin-left: 6px;';
          tagSpan.textContent = '🔖 ' + match.match_tags.slice(0, 3).join(', ');
          titleline.appendChild(tagSpan);
        }
      });
    } catch (e) {
      console.error('[HN Reader] batch match failed:', e);
    }
  }

  async function startPreload() {
    // 内容脚本被重复注入时只跑一次，避免双份预加载请求和双份轮询
    if (preloadStarted) return;
    preloadStarted = true;
    const rows = document.querySelectorAll('.athing');
    const articles = [];
    rows.forEach(row => {
      const titleline = row.querySelector('span.titleline');
      if (!titleline) return;
      const titleLink = titleline.querySelector('a');
      if (!titleLink) return;
      const hnId = parseInt(row.id, 10);
      if (!hnId) return;
      articles.push({
        hn_id: hnId,
        url: titleLink.href,
        title: titleLink.textContent
      });
    });

    if (articles.length === 0) return;

    const result = await chrome.storage.local.get(['hn_reader_language', 'hn_reader_auto_preload']);
    const lang = result['hn_reader_language'] || defaultSummaryLanguage();
    const autoPreload = !!result['hn_reader_auto_preload'];

    const allIds = articles.map(a => a.hn_id);

    // 只在开启自动预加载且非收藏页面时提交新的预加载请求；收藏页文章可能已总结过
    if (autoPreload && shouldPreloadNewArticles()) {
      const batch = articles.slice(0, PRELOAD_BATCH).map(a => ({
        hn_id: a.hn_id,
        url: a.url,
        title: a.title,
        lang: lang
      }));
      const { results, error } = await preloadArticles(batch);
      if (results) {
        applyPreloadResults(results);
        // 服务端可能截断或漏报个别条目，剩下的交给轮询兜底
        const reported = new Set(results.map(r => Number(r.hn_id)));
        batch.forEach(a => {
          if (!reported.has(Number(a.hn_id))) trackPending(a.hn_id);
        });
      } else if (error && error.status >= 400 && error.status < 500 && error.status !== 429) {
        // 请求本身被拒（鉴权、路径、旧服务端），等下去不会变好
        batch.forEach(a => markPreloadFailed(a.hn_id, 'request_failed'));
      } else {
        // 网络错误、超时、429 限流或旧版服务端：全部按待定处理，交给轮询兜底
        batch.forEach(a => trackPending(a.hn_id));
      }
    }

    // 总是查询当前页文章的已总结状态，刷新后恢复绿色标记
    // （手动加载的文章也会存入服务端缓存，可据此还原状态）
    await pollPreloadStatus(allIds, lang);

    // 仅开启自动预加载时才持续轮询，等待后台预加载完成
    if (autoPreload) {
      const intervalId = setInterval(async () => {
        // 慢响应时不要叠加轮询请求
        if (preloadPollInFlight) return;
        if (preloadPending.size > 0) {
          preloadPollInFlight = true;
          try {
            await pollPreloadStatus(Array.from(preloadPending), lang);
          } finally {
            preloadPollInFlight = false;
          }
        }
        expirePendingPreloads(lang);
        if (preloadPending.size === 0) {
          clearInterval(intervalId);
          preloadTimers.delete(intervalId);
        }
      }, PRELOAD_POLL_MS);
      preloadTimers.add(intervalId);

      // 页面卸载时停止所有轮询（含超时后的慢速复查）
      window.addEventListener('pagehide', clearPreloadTimers);
    }
  }

  function shouldPreloadNewArticles() {
    // 收藏页面是以前看过的文章，不要自动请求新的总结
    const path = window.location.pathname;
    return path !== '/fave' && path !== '/favorites';
  }

  async function shouldShowOnboarding() {
    try {
      const result = await chrome.storage.local.get(['hn_reader_onboarding_shown']);
      return !result['hn_reader_onboarding_shown'];
    } catch (e) {
      return false;
    }
  }

  async function markOnboardingShown() {
    try {
      await chrome.storage.local.set({ 'hn_reader_onboarding_shown': true });
    } catch (e) {
      console.error('[HN Reader] mark onboarding failed', e);
    }
  }

  function showOnboardingTooltip() {
    if (document.getElementById('hn-reader-onboarding')) return;

    const card = document.createElement('div');
    card.id = 'hn-reader-onboarding';
    card.className = 'hn-reader-popup';
    card.style.cssText = `
      position: fixed;
      z-index: 99999;
      bottom: 24px;
      right: 24px;
      width: 320px;
      background: #fff;
      border: 1px solid #ff6600;
      border-radius: 6px;
      padding: 16px;
      box-shadow: 0 4px 16px rgba(0,0,0,0.15);
      font-family: Verdana, Geneva, sans-serif;
      font-size: 12px;
      line-height: 1.6;
      color: #000;
    `;

    card.innerHTML = `
      <div style="font-weight:bold;font-size:13px;margin-bottom:8px;color:#ff6600;">${t('onboardingTitle')}</div>
      <ul style="margin:0 0 12px 16px;padding:0;">
        <li>${t('onboardingItem1')}</li>
        <li>${t('onboardingItem2')}</li>
        <li>${t('onboardingItem3')}</li>
      </ul>
      <button id="hn-reader-onboarding-close" style="background:#ff6600;color:#fff;border:none;padding:6px 14px;border-radius:3px;cursor:pointer;font-size:11px;">${t('onboardingDismiss')}</button>
    `;

    document.body.appendChild(card);

    document.getElementById('hn-reader-onboarding-close').addEventListener('click', () => {
      markOnboardingShown();
      card.remove();
    });

    // 10 秒后自动消失
    setTimeout(() => {
      if (card.parentNode) {
        card.remove();
      }
    }, 10000);
  }

  async function init() {
    console.log('[HN Reader] init() called, readyState:', document.readyState);
    await i18nReady;
    buildLabels();
    injectSummaryButtons();
    applyInterestMatches();
    // 延迟 2 秒后触发预加载/状态查询，等页面稳定
    // startPreload 内部会自己决定是否发送新的预加载请求；收藏页只查已有状态
    setTimeout(startPreload, 2000);

    if (await shouldShowOnboarding()) {
      showOnboardingTooltip();
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  if (!window.__hnReaderEscListenerAdded) {
    window.__hnReaderEscListenerAdded = true;
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        const popups = document.querySelectorAll('.hn-reader-popup');
        if (popups.length === 0) return;
        let topMost = null;
        let maxId = -1;
        popups.forEach(p => {
          const id = parseInt(p.dataset.hnReaderPopupId, 10);
          if (id > maxId) {
            maxId = id;
            topMost = p;
          }
        });
        if (topMost) {
          const popupHnId = parseInt(topMost.dataset.hnReaderHnId, 10);
          if (popupHnId) setSummaryBtnState(popupHnId, false);
          topMost.remove();
          e.stopPropagation();
        }
      }
    });
  }

  const observerTarget = document.body || document.documentElement;
  if (observerTarget) {
    const observer = new MutationObserver(() => {
      injectSummaryButtons();
    });
    observer.observe(observerTarget, { childList: true, subtree: true });
  }
})();
