const DOWNLOAD_URL = 'https://github.com/ejacky/hn-reader/releases/latest';

document.addEventListener('DOMContentLoaded', async () => {
  await ensureI18n();

  const statusEl = document.getElementById('status');

  // Cloud elements
  const cloudSection = document.getElementById('cloudSection');
  const switchToLocalBtn = document.getElementById('switchToLocalBtn');
  const quotaSection = document.getElementById('quotaSection');
  const quotaFill = document.getElementById('quotaFill');
  const quotaText = document.getElementById('quotaText');
  const quotaExhausted = document.getElementById('quotaExhausted');
  const exportDataBtn = document.getElementById('exportDataBtn');
  const deleteAccountBtn = document.getElementById('deleteAccountBtn');
  const cloudAccountStatus = document.getElementById('cloudAccountStatus');

  // Local elements
  const localSection = document.getElementById('localSection');
  const serverUrlInput = document.getElementById('serverUrl');
  const saveLocalBtn = document.getElementById('saveLocalBtn');
  const switchToCloudBtn = document.getElementById('switchToCloudBtn');
  const localGuide = document.getElementById('localGuide');

  // Connection
  const connIndicator = document.getElementById('connIndicator');
  const connText = document.getElementById('connText');

  // Auto preload toggle
  const autoPreloadToggle = document.getElementById('autoPreloadToggle');
  const autoPreloadResult = await chrome.storage.local.get([CONFIG.KEYS.AUTO_PRELOAD]);
  autoPreloadToggle.checked = !!autoPreloadResult[CONFIG.KEYS.AUTO_PRELOAD];

  autoPreloadToggle.addEventListener('change', async () => {
    await chrome.storage.local.set({ [CONFIG.KEYS.AUTO_PRELOAD]: autoPreloadToggle.checked });
    updateSummaryWarning();
    statusEl.textContent = t('statusSaved');
    statusEl.style.color = '#008000';
    setTimeout(() => statusEl.textContent = '', 2000);
  });

  // 语言设置：界面语言立即生效；摘要语言默认跟随界面，也可单独指定。
  const uiLanguageSelect = document.getElementById('uiLanguage');
  const summaryLanguageSelect = document.getElementById('summaryLanguage');
  const summaryLanguageWarning = document.getElementById('summaryLanguageWarning');

  function uiLanguageName() {
    return resolvedHtmlLang() === 'zh-CN' ? '中文' : 'English';
  }

  function updateSummaryFollowLabel() {
    summaryLanguageSelect.options[0].textContent = t('summaryLanguageFollow', [uiLanguageName()]);
  }

  function updateSummaryWarning() {
    summaryLanguageWarning.hidden = !autoPreloadToggle.checked;
  }

  const uiLanguageResult = await chrome.storage.local.get([CONFIG.KEYS.UI_LANGUAGE]);
  uiLanguageSelect.value = uiLanguageResult[CONFIG.KEYS.UI_LANGUAGE] || 'auto';
  uiLanguageSelect.addEventListener('change', async () => {
    await chrome.storage.local.set({ [CONFIG.KEYS.UI_LANGUAGE]: uiLanguageSelect.value });
    sessionStorage.setItem('hn_reader_ui_language_changed', '1');
    location.reload();
  });

  // 'auto'（跟随界面）不写存储；显式选择才写 hn_reader_language，选回跟随就删掉。
  const summaryResult = await chrome.storage.local.get([CONFIG.KEYS.LANGUAGE]);
  const storedSummaryLanguage = summaryResult[CONFIG.KEYS.LANGUAGE];
  summaryLanguageSelect.value = storedSummaryLanguage === 'zh' || storedSummaryLanguage === 'en'
    ? storedSummaryLanguage
    : 'auto';
  updateSummaryFollowLabel();
  updateSummaryWarning();

  summaryLanguageSelect.addEventListener('change', async () => {
    if (summaryLanguageSelect.value === 'auto') {
      await chrome.storage.local.remove([CONFIG.KEYS.LANGUAGE]);
    } else {
      await chrome.storage.local.set({ [CONFIG.KEYS.LANGUAGE]: summaryLanguageSelect.value });
    }
    statusEl.textContent = t('statusSaved');
    statusEl.style.color = '#008000';
    setTimeout(() => statusEl.textContent = '', 2000);
  });


  // Load config
  let cfg = await getReaderConfig();

  function showSection(mode) {
    cloudSection.style.display = 'none';
    localSection.style.display = 'none';

    if (mode === 'cloud') {
      cloudSection.style.display = 'block';
    } else if (mode === 'local') {
      localSection.style.display = 'block';
      serverUrlInput.value = cfg.serverUrl;
    }
  }

  showSection(cfg.mode);

  switchToLocalBtn.addEventListener('click', async (e) => {
    e.preventDefault();
    await setReaderConfig({ mode: 'local' });
    cfg = await getReaderConfig();
    showSection('local');
    await refreshConnection();
  });

  switchToCloudBtn.addEventListener('click', async (e) => {
    e.preventDefault();
    await setReaderConfig({ mode: 'cloud' });
    cfg = await getReaderConfig();
    showSection('cloud');
    await refreshConnection();
  });

  saveLocalBtn.addEventListener('click', async () => {
    const url = serverUrlInput.value.trim() || 'http://localhost:8080';
    if (!url.startsWith('http')) {
      statusEl.textContent = t('errInvalidUrl');
      statusEl.style.color = '#e00';
      return;
    }
    await setReaderConfig({
      mode: 'local',
      serverUrl: url
    });
    cfg = await getReaderConfig();
    statusEl.textContent = t('statusSaving');
    await refreshConnection();
  });

  exportDataBtn.addEventListener('click', async () => {
    const resp = await sendAction('apiRequest', { method: 'GET', path: '/api/account/export' });
    if (!resp.ok) {
      statusEl.textContent = t('errExportFailed', [resp.error || t('unknownError')]);
      statusEl.style.color = '#e00';
      return;
    }
    const blob = new Blob([JSON.stringify(resp.data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'hn-reader-export.json';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    statusEl.textContent = t('statusExported');
    statusEl.style.color = '#008000';
  });

  deleteAccountBtn.addEventListener('click', async () => {
    if (!confirm(t('confirmDeleteAccount'))) return;
    const resp = await sendAction('apiRequest', { method: 'DELETE', path: '/api/account' });
    if (!resp.ok) {
      statusEl.textContent = t('errDeleteFailed', [resp.error || t('unknownError')]);
      statusEl.style.color = '#e00';
      return;
    }
    await chrome.storage.local.remove([CONFIG.KEYS.CLOUD_TOKEN]);
    cloudAccountStatus.textContent = t('cloudDataDeleted');
    quotaSection.style.display = 'none';
    quotaExhausted.style.display = 'none';
    statusEl.textContent = t('accountDeletedHint');
    statusEl.style.color = '#008000';
  });

  async function sendAction(action, payload = {}) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ action, payload }, (resp) => {
        resolve(resp || { ok: false, error: t('errNoResponse') });
      });
    });
  }

  async function refreshConnection() {
    cfg = await getReaderConfig();
    connText.textContent = t('connChecking');
    connIndicator.style.color = '#999';
    statusEl.textContent = '';

    const probe = await sendAction('probeConnection');

    if (probe.ok && probe.data.connected) {
      connIndicator.style.color = '#008000';
      const info = probe.data.info || {};
      connText.textContent = cfg.mode === 'cloud' ? t('cloudConnected') : t('localConnected');
      statusEl.textContent = t('connectSuccess');
      statusEl.style.color = '#008000';
      localGuide.style.display = 'none';

      if (cfg.mode === 'cloud') {
        await loadCloudMeta();
      }
      await loadServerData();
    } else {
      connIndicator.style.color = '#e00';
      connText.textContent = cfg.mode === 'cloud' ? t('cloudDisconnected') : t('localDisconnected');
      statusEl.textContent = probe.ok ? t('errCannotConnect') : (probe.error || t('errCannotConnect'));
      statusEl.style.color = '#e00';
      if (cfg.mode === 'local') {
        localGuide.style.display = 'block';
      }
      hideDataSections();
    }
  }

  async function loadCloudMeta() {
    const resp = await sendAction('apiRequest', { method: 'GET', path: '/auth/me' });
    if (!resp.ok || !resp.data) {
      cloudAccountStatus.textContent = t('accountAnonymous');
      return;
    }

    const { plan, quota_used, quota_limit, quota_reset_at } = resp.data;
    cloudAccountStatus.textContent = plan === 'free' ? t('accountAnonymousFree') : (plan || t('accountAnonymous'));

    quotaSection.style.display = 'block';
    const used = quota_used || 0;
    const limit = quota_limit || 50;
    const pct = Math.min(100, Math.round((used / limit) * 100));
    quotaFill.style.width = `${pct}%`;
    quotaFill.style.background = pct >= 90 ? '#e00' : '#ff6600';

    const reset = quota_reset_at ? new Date(quota_reset_at) : null;
    const resetText = reset && !isNaN(reset.getTime()) ? t('quotaReset', [reset.toLocaleDateString()]) : '';
    quotaText.textContent = t('quotaUsage', [String(used), String(limit)]) + resetText;

    quotaExhausted.style.display = used >= limit ? 'block' : 'none';
    if (used >= limit) {
      quotaFill.style.background = '#e00';
    }
  }

  async function loadServerData() {
    const statsSection = cfg.mode === 'cloud' ? document.getElementById('cloudStatsSection') : document.getElementById('localStatsSection');
    const statsContent = cfg.mode === 'cloud' ? document.getElementById('cloudStatsContent') : document.getElementById('localStatsContent');
    const recSection = cfg.mode === 'cloud' ? document.getElementById('cloudRecSection') : document.getElementById('localRecSection');
    const recContent = cfg.mode === 'cloud' ? document.getElementById('cloudRecContent') : document.getElementById('localRecContent');

    try {
      const statsResp = await sendAction('getStats');
      if (statsResp.ok) {
        const stats = statsResp.data;
        statsSection.style.display = 'block';
        let html = `<p>${t('statsTotalSignals')} <strong>${stats.total_signals || 0}</strong></p>`;
        if (stats.by_type) {
          html += '<ul>';
          for (const [type, count] of Object.entries(stats.by_type)) {
            html += `<li>${type}: ${count}</li>`;
          }
          html += '</ul>';
        }
        statsContent.innerHTML = html;
      }
    } catch (e) {
      console.error('stats fetch failed', e);
    }

    try {
      const recResp = await sendAction('getRecommendations', { limit: 5 });
      if (recResp.ok) {
        const data = recResp.data;
        if (data.recommendations && data.recommendations.length > 0) {
          recSection.style.display = 'block';
          let html = '<ul>';
          for (const rec of data.recommendations) {
            html += `<li><a href="https://news.ycombinator.com/item?id=${rec.hn_id}" target="_blank">${rec.title}</a><br><small>${rec.reason}</small></li>`;
          }
          html += '</ul>';
          recContent.innerHTML = html;
        }
      }
    } catch (e) {
      console.error('rec fetch failed', e);
    }
  }

  function hideDataSections() {
    ['cloudStatsSection', 'cloudRecSection', 'localStatsSection', 'localRecSection', 'quotaSection', 'quotaExhausted'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.style.display = 'none';
    });
  }

  await refreshConnection();

  // 刚切换过界面语言：连接状态之后提示，避免被 refreshConnection 覆盖。
  if (sessionStorage.getItem('hn_reader_ui_language_changed')) {
    sessionStorage.removeItem('hn_reader_ui_language_changed');
    const hint = t('uiLanguageChangedHint');
    statusEl.textContent = hint;
    statusEl.style.color = '#008000';
    setTimeout(() => {
      if (statusEl.textContent === hint) statusEl.textContent = '';
    }, 6000);
  }
});
